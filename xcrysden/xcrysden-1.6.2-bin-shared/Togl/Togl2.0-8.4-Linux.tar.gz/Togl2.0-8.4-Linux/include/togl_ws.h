#ifndef TOGL_WS_H
# define TOGL_WS_H

/* define windowing system togl is compiled with */
# define TOGL_X11

#endif
